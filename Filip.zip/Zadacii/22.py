#Zapisati sve parne i neparne broje od n do m

n = int(input("Unesite broj N: "))
m = int(input("Unesite broj M: "))
n2=n
m2=m
if (n > m):
    print("Prvi broj mora biti manji od drugog!!! Pokusajte ponovo\n")
    n = int(input("Unesite broj N: "))
    m = int(input("Unesite broj M: "))

print("Parni brojevi su: ")
while n < m:
    if(n%2==0):
        print(f"{n} ")
    n+=1

print("Neparni brojevi su: ")
while n2 < m2:
    if(n2%2!=0):
        print(f"{n2} ")
    n2+=1
        

