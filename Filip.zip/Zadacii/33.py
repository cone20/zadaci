#Ispisati sve brojeve od N do M ukljucujuci N i M

n = int(input("Unesite broj N: "))
m = int(input("Unesite broj M: "))

if (n > m):
    print("Prvi broj mora biti manji od drugog!!! Pokusajte ponovo\n")
    n = int(input("Unesite broj N: "))
    m = int(input("Unesite broj M: "))
    
while n < m+1:
    print(f"{n} ")
    n+=1