#Za uneti broj ispisati n naredna broja.

broj = int(input("Od broja: "))
n = int(input("Koliko narednih brojeva: "))
z = n
n = n + broj
print(f"Od broja: {broj}")
print(f"Narednih: {z}")
for x in range(broj+1, n+1,1):
    print(x)
    