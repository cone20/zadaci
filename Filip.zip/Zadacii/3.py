#Zapisati sve parne i neparne broje od n do m

n = int(input("Unesite broj N: "))
m = int(input("Unesite broj M: "))

for value in range(n + 1,m + 1):
    if(value%2==0):
        print(f"Parn je: {value}")
    
for value in range(n + 1,m + 1):
    if(value%2!=0):
        print(f"Neparan je: {value}")       
