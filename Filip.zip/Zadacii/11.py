#Sabrati brojeve od N do M, ako je N manje od M

n = int(input("Unesite broj N: "))
m = int(input("Unesite broj M: "))
n2=n
m2=m
suma = 0
proizvod = 1
if (n > m):
    print("Prvi broj mora biti manji od drugog!!! Pokusajte ponovo\n")
    n = int(input("Unesite broj N: "))
    m = int(input("Unesite broj M: "))

while (n <= m):
    suma += n
    n += 1
print(f"Suma je : {suma}")

while (n2 <= m2):
    proizvod = proizvod * n2
    n2 += 1
print(f"Proizvod je : {proizvod}")

