#Sabrati i pomnoziti brojeve od N do M

n = int(input("Unesite broj N: "))
m = int(input("Unesite broj M: "))
sum = 0
proizvod = 1
for value in range(n,m + 1):
    print(f"{value} ")
    sum = sum + value
    
print(f"Suma je: {sum}")

for value in range(n,m + 1):
    print(f"{value} ")
    proizvod = proizvod * value
    
print(f"Proizvod je: {proizvod}")